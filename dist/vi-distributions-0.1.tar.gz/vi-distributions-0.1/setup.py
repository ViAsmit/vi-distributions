from setuptools import setup

setup(name='vi-distributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['vi-distributions'],
      zip_safe=False)
